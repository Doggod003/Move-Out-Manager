import { useState, useEffect } from 'react'

const STORAGE_KEY = 'moveout-os-min'

const SAMPLE_PROPERTIES = [
  { id: 1, name: 'Riverside Main House', icon: '🏠', accent: '#0d6efd', address: '142 River Rd, Harrisburg, PA', moveDate: '+45d', status: 'Listed', taskPct: 78, vendors: 2, spent: 2275, budget: 8000 },
  { id: 2, name: 'Beach Cottage', icon: '🏖️', accent: '#0ea5e9', address: '88 Ocean Ave, Cape May, NJ', moveDate: '+20d', status: 'Under contract', taskPct: 65, vendors: 2, spent: 2275, budget: 5000 },
  { id: 3, name: 'Downtown Rental 3B', icon: '🏢', accent: '#8b5cf6', address: '500 Market St, Philadelphia, PA', moveDate: '+8d', status: 'Tenant move-out', taskPct: 32, vendors: 0, spent: 0, budget: 1200 },
  { id: 4, name: 'Mountain Cabin Retreat', icon: '🏕️', accent: '#16a34a', address: '1212 Pine Trail, Stroudsburg, PA', moveDate: '+60d', status: 'Prepping', taskPct: 12, vendors: 0, spent: 0, budget: 0 },
  { id: 5, name: 'Investment Flip on Maple', icon: '💼', accent: '#0d9488', address: '77 Maple St, Lancaster, PA', moveDate: '+3d', status: 'Closing soon', taskPct: 88, vendors: 0, spent: 0, budget: 0 },
]

export default function App() {
  const [view, setView] = useState('landing')
  const [properties, setProperties] = useState([])

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      if (saved) setProperties(JSON.parse(saved))
    } catch {}
  }, [])

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(properties)) } catch {}
  }, [properties])

  if (view === 'landing') return <Landing onEnterApp={() => setView('app')} />
  return <AppShell properties={properties} onLoadDemo={() => setProperties(SAMPLE_PROPERTIES)} onClear={() => setProperties([])} onBack={() => setView('landing')} />
}

function Landing({ onEnterApp }) {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="sticky top-0 z-40 backdrop-blur-md bg-slate-50/80 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <Logo />
          <div className="flex items-center gap-3">
            <button onClick={onEnterApp} className="text-sm text-slate-600 hover:text-slate-900 hidden sm:inline">Sign in</button>
            <button onClick={onEnterApp} className="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium px-4 py-2 rounded-lg flex items-center gap-1.5 shadow-sm transition">
              Start free trial →
            </button>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 pt-20 pb-24 lg:pt-28 lg:pb-32">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-100 text-indigo-700 text-xs font-medium mb-6">
              <span className="text-base">✨</span> AI-native, not AI-bolted-on
            </div>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-slate-900 leading-[0.95]">
              Move-outs that <span className="text-indigo-600">run themselves</span>.
            </h1>
            <p className="mt-6 text-xl text-slate-600 max-w-2xl leading-relaxed">
              The first move-out platform with an AI agent that auto-checks tasks, allocates budgets, suggests vendors, and tells you what to do next — all silently in the background.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-3">
              <button onClick={onEnterApp} className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium px-5 py-3 rounded-lg shadow-sm transition">
                Start free — no credit card →
              </button>
              <button onClick={onEnterApp} className="bg-white border border-slate-200 hover:border-slate-300 text-slate-700 font-medium px-5 py-3 rounded-lg transition">
                See live demo
              </button>
            </div>
            <div className="mt-8 flex flex-wrap items-center gap-6 text-sm text-slate-500">
              <span className="flex items-center gap-1.5">✓ Free up to 3 properties</span>
              <span className="flex items-center gap-1.5">✓ 14-day pro trial</span>
              <span className="flex items-center gap-1.5">✓ No CC required</span>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-[42rem] h-[42rem] -mr-32 -mt-32 pointer-events-none">
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-indigo-300/40 via-indigo-200/20 to-transparent blur-3xl" />
        </div>
      </section>

      <section className="py-24 bg-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-6">
          <div className="max-w-2xl mb-16">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-slate-900">Everything you need to ship a move-out cleanly.</h2>
            <p className="mt-4 text-lg text-slate-600">From the first listing to the keys handover.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              ['✨', 'Autonomous AI agent', 'Auto-checks tasks, suggests vendors, allocates budgets — all silently as you work.'],
              ['📅', 'Calendar & timeline', 'See every move-out across your portfolio. Drag tasks to reschedule.'],
              ['📊', 'Reports & closing packets', 'One-click PDF closing packets. Portfolio analytics. Tax-ready expense exports.'],
              ['👥', 'Team collaboration', 'Invite agents, vendors, clients. Role-based access. Real-time updates.'],
              ['📁', 'Document vault', 'Centralize leases, inspections, receipts, photos.'],
              ['📷', 'Walkthrough mode', 'Mobile-first companion for on-site work. Photograph rooms, check tasks instantly.'],
              ['💬', 'Chat with each property', 'Ask "what\'s left to do?" Your AI co-pilot knows the full context of every property.'],
              ['🏢', 'Vendor directory', 'Build a roster of trusted vendors. AI suggests the right ones for each property.'],
              ['🛡️', 'Built for portfolios', 'Whether you manage 3 or 300, MoveOut OS scales.'],
            ].map(([icon, title, desc]) => (
              <div key={title} className="p-6 rounded-2xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:border-slate-300 hover:shadow-sm transition-all">
                <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center mb-4 text-xl">{icon}</div>
                <h3 className="font-semibold text-slate-900 text-base mb-1.5">{title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-slate-950 text-white">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-6xl font-bold tracking-tight">Stop juggling spreadsheets.</h2>
          <p className="mt-6 text-xl text-slate-400">Start your next move-out in MoveOut OS. The AI does the rest.</p>
          <div className="mt-10">
            <button onClick={onEnterApp} className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium px-6 py-3 rounded-lg text-base transition">
              Get started free →
            </button>
          </div>
        </div>
      </section>

      <footer className="py-10 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-6 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Logo />
            <span className="text-sm text-slate-500">© 2026</span>
          </div>
          <p className="text-sm text-slate-500">Built with ❤️ for property pros</p>
        </div>
      </footer>
    </div>
  )
}

function Logo() {
  return (
    <div className="flex items-center gap-2">
      <svg width="28" height="28" viewBox="0 0 32 32" fill="none">
        <rect width="32" height="32" rx="7" fill="#4f46e5" />
        <path d="M8 12L16 6L24 12V24H19V18H13V24H8V12Z" fill="white" />
        <circle cx="22" cy="10" r="3" fill="#facc15" />
      </svg>
      <span className="font-semibold text-slate-900 tracking-tight text-base">
        MoveOut <span className="text-indigo-600">OS</span>
      </span>
    </div>
  )
}

function AppShell({ properties, onLoadDemo, onClear, onBack }) {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="text-slate-500 hover:text-slate-900 text-sm">← Home</button>
          <Logo />
        </div>
        <div className="flex items-center gap-3">
          <span className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-medium">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span> AI active
          </span>
          {properties.length > 0 && (
            <button onClick={onClear} className="text-xs text-slate-500 hover:text-rose-600 px-2 py-1">Clear</button>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {properties.length === 0 ? (
          <EmptyState onLoadDemo={onLoadDemo} />
        ) : (
          <Dashboard properties={properties} />
        )}
      </main>
    </div>
  )
}

function EmptyState({ onLoadDemo }) {
  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center mx-auto mb-6 text-3xl">🏢</div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Welcome to MoveOut OS</h2>
        <p className="text-slate-600 mt-2 leading-relaxed">Your AI-powered move-out workspace. Start with the demo portfolio to see what it can do.</p>
        <div className="mt-7 flex flex-col gap-2">
          <button onClick={onLoadDemo} className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2.5 rounded-lg flex items-center justify-center gap-2 transition">
            ✨ Load demo portfolio
          </button>
        </div>
      </div>
    </div>
  )
}

function Dashboard({ properties }) {
  const totalSpent = properties.reduce((s, p) => s + p.spent, 0)
  const avgPct = Math.round(properties.reduce((s, p) => s + p.taskPct, 0) / properties.length)
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">Dashboard</h1>
        <p className="text-sm text-slate-600 mt-1">{properties.length} properties · {avgPct}% portfolio complete</p>
      </div>

      <div className="mb-6 rounded-2xl bg-gradient-to-br from-indigo-50 via-white to-amber-50 border border-indigo-200/60 p-5">
        <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-indigo-700 mb-3">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
          Daily briefing
        </div>
        <p className="text-base font-medium text-slate-900 leading-snug mb-3">
          Two properties need attention today; Investment Flip on Maple closes in 3 days but is 88% complete — almost there.
        </p>
        <div className="text-sm text-slate-700">💰 Currently ${totalSpent.toLocaleString()} spent across portfolio. On track with budget overall.</div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {[
          ['Properties', properties.length, 'bg-indigo-100 text-indigo-700'],
          ['Avg progress', avgPct + '%', 'bg-slate-200 text-slate-700'],
          ['Move-ready', properties.filter(p => p.taskPct === 100).length, 'bg-emerald-100 text-emerald-700'],
          ['Total spent', '$' + totalSpent.toLocaleString(), 'bg-amber-100 text-amber-700'],
        ].map(([label, value, color]) => (
          <div key={label} className="rounded-xl border border-slate-200 bg-white p-4 hover:shadow-sm transition-shadow">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium uppercase tracking-wider text-slate-500">{label}</span>
              <span className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs ${color}`}>•</span>
            </div>
            <div className="text-2xl font-bold text-slate-900 tracking-tight">{value}</div>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        <h2 className="text-base font-semibold text-slate-900">Your properties</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {properties.map(p => <PropertyCard key={p.id} p={p} />)}
        </div>
      </div>
    </div>
  )
}

function PropertyCard({ p }) {
  const isReady = p.taskPct === 100
  return (
    <div className="rounded-xl bg-white border border-slate-200 hover:border-slate-300 hover:shadow-sm transition-all overflow-hidden relative">
      <div className="absolute top-0 left-0 bottom-0 w-1" style={{ background: isReady ? '#10b981' : p.accent }} />
      <div className="p-4 pl-5">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <div className="w-9 h-9 rounded-full flex items-center justify-center text-base flex-shrink-0" style={{ background: p.accent + '1f' }}>{p.icon}</div>
            <div className="min-w-0 flex-1">
              <div className="font-semibold text-slate-900 truncate">{p.name}</div>
              <div className="text-xs text-slate-500 truncate">{p.address}</div>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1 flex-shrink-0">
            <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">{p.status}</span>
            <span className="text-xs font-medium text-slate-500">{p.moveDate}</span>
          </div>
        </div>
        <div className="flex items-center gap-2.5 mb-3">
          <div className="flex-1 h-1.5 rounded-full bg-slate-100 overflow-hidden">
            <div className="h-full rounded-full transition-all duration-500" style={{ width: `${p.taskPct}%`, background: isReady ? '#10b981' : p.accent }} />
          </div>
          <span className="text-xs font-semibold text-slate-700 tabular-nums w-9 text-right">{p.taskPct}%</span>
        </div>
        <div className="grid grid-cols-3 gap-2 pt-3 border-t border-dashed border-slate-200 text-[11px]">
          <div><div className="text-slate-500 mb-0.5">Vendors</div><div className="font-semibold text-slate-900">{p.vendors}</div></div>
          <div><div className="text-slate-500 mb-0.5">Spent</div><div className="font-semibold text-slate-900">${p.spent}</div></div>
          <div><div className="text-slate-500 mb-0.5">Budget</div><div className="font-semibold text-slate-900">${p.budget || '—'}</div></div>
        </div>
        <div className="mt-3 flex items-start gap-2 px-3 py-2 rounded-lg bg-indigo-50 border border-indigo-200/60">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse mt-1.5 flex-shrink-0"></span>
          <p className="text-xs text-indigo-900 leading-snug truncate flex-1">
            {p.taskPct < 50 ? 'Lock in vendors this week — moving date approaches.' : p.taskPct < 100 ? 'Almost there — schedule the final clean.' : 'Move-ready! Final walkthrough only.'}
          </p>
        </div>
      </div>
    </div>
  )
}
